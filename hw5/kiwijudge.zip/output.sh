echo "10000" | ./gen_short > __input.txt
echo "Generated input"
./service Manager < __input.txt > __raw_output.txt
echo "Generated raw output"
python3 transformer.py __raw_output.txt > __transformed_output.txt
echo "Generated transformed output"
./checker < __input.txt > __correct_output.txt
echo "Generated correct output"
DIFF=$(diff __transformed_output.txt __correct_output.txt)
if [ "$DIFF" != "" ]
then
    echo "Wrong Output"
else
    rm __input.txt
    rm __raw_output.txt
    rm __correct_output.txt
    rm __transformed_output.txt
    echo "Cleaned unused file"
fi
